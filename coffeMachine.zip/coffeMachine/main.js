function CoffeeMachine(power) {
    this.waterAmount = 100;
    const WATER_HEAT_CAPACITY = 4200;

    let getBoilTime = function () {
        if (this.waterAmount > 100) {
            let time = this.waterAmount * WATER_HEAT_CAPACITY * 80 / power;
            console.log(time);
            return time;
        }


    }.bind(this);

    let onReady = function () {
        if(this.waterAmount >= 100){
        alert('Кава готова');
        this.waterAmount -= 100;
        console.log(this.waterAmount);
        }else{alert('кавоварка сгоріла')}
        level = level - 10;

    waterLevel.style.height = level + '%';
    waterLevel.innerText = level + '%';
    $('.waterLevel').css('background-color','rgb(44, 20, 3)')

        
    }.bind(this);



    let timerId;

    this.run = () => {
        timerId = setTimeout(onReady, getBoilTime());
        
    }

    this.stop = () => {
        clearTimeout(timerId);
        console.log('Приготуваня кави було припинено');
    }

    this.addWater = () => {
        if (this.waterAmount <= 900) {
            this.waterAmount += 100;
            console.log(this.waterAmount);
        } else {
            alert('Стакан повний');
        }
    }
    this.minWater = () => {
        if (this.waterAmount > 100) {
            this.waterAmount -= 100;
            console.log(this.waterAmount);
        } else {
            alert('Стакан пустий');
        }
    }
    

}


let coffeMachine = new CoffeeMachine(10000);
coffeMachine.waterAmount = 200;

runBtn.onclick = function () {
        coffeMachine.run();
  
    
}

stopBtn.onclick = function () {
    coffeMachine.stop();
}

cleanBtn.onclick = function () {
    $('.waterLevel').css('background-color','rgb(82, 149, 221)')
}


let level = 10;
waterLevel.innerText = level + '%';

minWaterBtn.onclick = function () {
    coffeMachine.minWater();
    level = level - 10;
    this.waterAmount = 100
    waterLevel.style.height = level + '%';
    waterLevel.innerText = level + '%';

}
addWaterBtn.onclick = function () {
    coffeMachine.addWater();
    level = level + 10;
    this.waterAmount = 100
    waterLevel.style.height = level + '%';
    waterLevel.innerText = level + '%';

}